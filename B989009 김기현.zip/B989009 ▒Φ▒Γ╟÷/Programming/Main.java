package Programming;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.StringTokenizer;

class Main {
    public static void main(String[] args) throws IOException {
        String fname = args[1];
        String scheduling = args[2];

        FileInputStream fr = new FileInputStream(fname);
        BufferedReader br = new BufferedReader(new InputStreamReader(fr));
        StringTokenizer st = new StringTokenizer(br.readLine(), "( )");
        int T = Integer.parseInt(st.nextToken());
        
        for(int t = 0; t < T; t++) {
            int A = Integer.parseInt(st.nextToken());
            int C = Integer.parseInt(st.nextToken());
            int B = Integer.parseInt(st.nextToken());
            int IO = Integer.parseInt(st.nextToken());
            CPUScheduler.addProcess(new pcb(A, C, B, IO));
        }

        br.close();

        switch(scheduling) {
            case "FCFS":
                CPUScheduler.setScheduling(FCFS.getInstance());
                break;
            case "RR1":
                CPUScheduler.setScheduling(RR1.getInstance());
                break;
            case "RR10":
                CPUScheduler.setScheduling(RR10.getInstance());
                break;
            case "RR100":
                CPUScheduler.setScheduling(RR100.getInstance());
                break;
            case "SJF":
                CPUScheduler.setScheduling(SJF.getInstance());
                break;
            default:
                System.out.println("Not exist scheduling");
        }
        CPUScheduler.run();
    }
}