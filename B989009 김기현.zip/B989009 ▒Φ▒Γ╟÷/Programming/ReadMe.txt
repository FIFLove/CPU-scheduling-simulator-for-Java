--ReadMe--

1. If you have unzipped this folder, please open this unzipped folder in cmd. The folder name is B989009 김기현.

2. Enter the following command in the cmd terminal. FCFS at the end has FCFS, RR1, RR10, RR100, and SJF as scheduling methods

java Programming.Main 2 Programming\test.txt FCFS

3. If you want to see other examples, you can change the process example in test.txt. However, we are not responsible for any compilation errors that are out of format.

Please send your questions to watergon1126@naver.com. thank you!



1. 이 폴더를 압축 해제하셨으면, cmd에서 압축을 해제한 이 폴더를 열어주세요. 폴더 이름은 B989009 김기현 입니다.

2.  cmd 터미널에서 다음 명령어를 입력해주세요. 맨 뒤의 FCFS는 스케줄링 방식으로 FCFS, RR1, RR10, RR100, SJF가 있습니다.

java Programming.Main 2 Programming\test.txt FCFS

3. 다른 예제를 보고싶으시면 test.txt의 프로세스 예제를 바꿔주시면 됩니다. 단, 형식에 어긋날 경우에 대한 컴파일 오류가 나는 것에 대한 책임은 지지 않습니다.

질문은 watergon1126@naver.com으로 보내주세요. 감사합니다!