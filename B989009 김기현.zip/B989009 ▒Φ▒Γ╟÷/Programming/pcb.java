package Programming;

import java.util.Random;

public class pcb {
    int pid;    // pid
    int A;      // Arrival time
    int B;      // CPU Burst time 
    int C;      // CPU time
    int IO;     // IO Burst time

    int remaining_cpu_time;
    int cburst;
    int remaining_cburst;
    int ioburst;
    int remaining_ioburst;

    int Finishing_Time;
    int Turnaround_Time;
    int CPU_Time;
    int IO_Time;
    int Waiting_Time;

    IpcbState state;

    Random rand = new Random();
    
    public pcb (int A, int C, int B, int IO) {
        this.A = A;
        this.C = C;
        this.B = B;
        this.IO = IO;

        this.remaining_cpu_time = C;
        this.setcburst();
        this.remaining_cburst = cburst;
        this.setioburst();
        this.remaining_ioburst = ioburst;

        this.Finishing_Time = 0;
        this.Turnaround_Time = 0;
        this.CPU_Time = 0;
        this.IO_Time = 0;
        this.Waiting_Time = 0;

        this.state = Nonexistent.getInstance();
    }

    public void timed() {
        this.state.timed(this);
    }

    public void setState(IpcbState s) {
        state = s;
    }

    public String getState() {
        return state.getState();
    }

    public int decrease_rct() {
        remaining_cpu_time--;
        return remaining_cpu_time;
    }

    public int decrease_c() {
        remaining_cburst--;
        return remaining_cburst;
    }

    public int decrease_i() {
        remaining_ioburst--;
        return remaining_ioburst;
    }

    public int increase_FT() {
        Finishing_Time++;
        return Finishing_Time;
    }

    public int increase_TT() {
        Turnaround_Time++;
        return Turnaround_Time;
    }

    public int increase_CT() {
        CPU_Time++;
        return CPU_Time;
    }

    public int increase_IT() {
        IO_Time++;
        return IO_Time;
    }

    public int increase_WT() {
        Waiting_Time++;
        return Waiting_Time;
    }

    public int setcburst() {
        cburst = rand.nextInt(B) + 1;
        remaining_cburst = cburst;
        return cburst;
    }

    public int setioburst() {
        ioburst = rand.nextInt(IO + 1);
        remaining_ioburst = ioburst;
        return ioburst;
    }

    public void display() {
        System.out.println("(" + A + ", " + C + ", " + B + ", " + IO + ")");
        System.out.println("Finishing Time : " + Finishing_Time);
        System.out.println("Turnaround Time : " + Turnaround_Time);
        System.out.println("CPU Time : " + CPU_Time);
        System.out.println("I/O Time : " + IO_Time);
        System.out.println("Waiting Time : " + Waiting_Time);
    }
}

interface IpcbState {
    public void timed(pcb p);
    public String getState();
}

class Nonexistent implements IpcbState {
    private static Nonexistent instance = new Nonexistent();
    private Nonexistent() {}
    public static Nonexistent getInstance() {
        return instance;
    }
    public void timed(pcb p) {
        p.increase_FT();
    }
    public String getState() {
        return "Nonexistent";
    }
}

class Running implements IpcbState {
    private static Running instance = new Running();
    private Running() {}
    public static Running getInstance() {
        return instance;
    }
    public void timed(pcb p) {
        p.increase_FT();
        p.increase_TT();
        p.increase_CT();

        p.decrease_rct();
        p.decrease_c();
    }
    public String getState() {
        return "Running";
    }
}

class Blocked implements IpcbState {
    private static Blocked instance = new Blocked();
    private Blocked() {}
    public static Blocked getInstance() {
        return instance;
    }
    public void timed(pcb p) {
        p.increase_FT();
        p.increase_TT();
        p.increase_IT();

        p.decrease_i();
    }
    public String getState() {
        return "Blocked";
    }
}

class Ready implements IpcbState {
    private static Ready instance = new Ready();
    private Ready() {}
    public static Ready getInstance() {
        return instance;
    }
    public void timed(pcb p) {
        p.increase_FT();
        p.increase_TT();
        p.increase_WT();
    }
    public String getState() {
        return "Ready";
    }
}

class Terminated implements IpcbState {
    private static Terminated instance = new Terminated();
    private Terminated() {}
    public static Terminated getInstance() {
        return instance;
    }
    public void timed(pcb p){}
    public String getState() {
        return "Terminated";
    }
}