package Programming;

import java.util.LinkedList;
import java.util.Iterator;

public class WaitingQueue {
    private static WaitingQueue instance = new WaitingQueue();
    private WaitingQueue() {}
    public static WaitingQueue getInstance() {
        return instance;
    }

    private static LinkedList<pcb> pcbs = new LinkedList<>();
    public static void addProcess(pcb p) {
        pcbs.add(p);
    }
    public static void pollProcess(int index) {
        pcbs.remove(index);
    }
    public static void run() {
        Iterator<pcb> ip = pcbs.iterator();
        while(ip.hasNext())
        {
            pcb p = ip.next();
            if (p.getState().equals("Blocked") && p.remaining_ioburst == 0) {
                ReadyQueue.insertProcess(p);
                p.setState(Ready.getInstance());
                p.setioburst();
                ip.remove();
            }
        }
    }
    public static boolean isEmpty() {
        return pcbs.isEmpty();
    }
}