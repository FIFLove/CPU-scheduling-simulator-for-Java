package Programming;

public class CPU {
    private static CPU instance = new CPU();
    private static pcb process;

    private CPU() {}

    public static CPU getInstance() {
        return instance;
    }


    public static void setProcess(pcb p) {
        process = p;
    }

    public static void run() {
        if(process != null) {
            if(process.getState().equals("Running") && process.remaining_cpu_time == 0) {
                process.setState(Terminated.getInstance());
                CPUScheduler.terminate();
                process = null;
            }
            else if(process.getState().equals("Running") && process.remaining_cburst == 0) {
                // System.out.println("Blocked");
                process.setState(Blocked.getInstance());
                WaitingQueue.addProcess(process);
                process.setcburst();
                process = null;
            }
        }
    }

    public static void preemption() {
        if(process != null) {
            process.setState(Ready.getInstance());
            ReadyQueue.insertProcess(process);
            process = null;
        }
    }

    public static boolean isEmpty() {
        if(process == null) return true;
        else return false;
    }
}