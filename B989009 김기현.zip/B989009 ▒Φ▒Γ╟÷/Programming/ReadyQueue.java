package Programming;

import java.util.LinkedList;
import java.util.Collections;

public class ReadyQueue {
    private static ReadyQueue instance = new ReadyQueue();
    private ReadyQueue() {
    }
    public static ReadyQueue getInstance() {
        return instance;
    }

    private static LinkedList<pcb> pcbs = new LinkedList<>();
    public static void insertProcess(pcb p) {
        pcbs.add(p);
    }
    public static pcb pollProcess() {
        return pcbs.poll();
    }
    public static void sortProcess() {
        Collections.sort(pcbs, (a, b) -> a.C - b.C);
    }

    public static void run() {
        // System.out.println("run");
        if(CPU.isEmpty() && !pcbs.isEmpty()) {
            pcb p = pollProcess();
            p.setState(Running.getInstance());
            CPU.setProcess(p);
        }
    }
}

