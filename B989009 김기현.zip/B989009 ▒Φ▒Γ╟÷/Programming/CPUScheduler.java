package Programming;

import java.util.LinkedList;

public class CPUScheduler {
    private static CPUScheduler instance = new CPUScheduler();
    public static Strategy scheduling;
    private CPUScheduler() {
        scheduling = FCFS.getInstance();
    }
    public static CPUScheduler getInstance() {
        return instance;
    }
    public static void setScheduling(Strategy st) {
        scheduling = st;
    }
    private static LinkedList<pcb> pcbs = new LinkedList<>();
    private static int live = 0;
    public static void terminate() {
        live--;
        // System.out.println("live processes : " + live);
    }
    public static LinkedList<pcb> getpcbs() {
        return pcbs;
    }
    public static void addProcess(pcb p) {
        pcbs.add(p);
    }
    public static void pollProcess(int index) {
        pcbs.remove(index);
    }


    private static int time = 0;

    public static int gettime() {
        return time;
    }

    public static int reset() {
        int temp = time;
        time = 0;
        return temp;
    }

    public static void run() {
        live = pcbs.size();
        while(live != 0) {
            for(pcb p : pcbs) {
                if(p.getState().equals("Nonexistent") && p.A == time) {
                    ReadyQueue.insertProcess(p);
                    p.setState(Ready.getInstance());
                }
            }
            scheduling.scheduling();
            time++;
        }
        displayResult();
    }

    public static void displayResult() {
        int process_num = 1;
        int Finishing_Time = 0;

        int CPU_occupation = 0;
        int IO_occupation = 0;
        int Sum_tt = 0;
        int Sum_wt = 0;

        float CPU_utilization = 0;
        float IO_utilization = 0;
        float Throughput = 0;
        float Avg_tt = 0;
        float Avg_wt = 0;

        for(pcb p : pcbs) {
            System.out.println("--- process" + process_num++ + " ---");
            p.display();
            if(p.Finishing_Time > Finishing_Time) Finishing_Time = p.Finishing_Time;
            CPU_occupation += p.CPU_Time;
            IO_occupation += p.IO_Time;
            Sum_tt += p.Turnaround_Time;
            Sum_wt += p.Waiting_Time;
            System.out.println();
        }

        System.out.println("-------------------");
        System.out.println();

        CPU_utilization = (float)CPU_occupation / Finishing_Time;
        IO_utilization = (float)IO_occupation / Finishing_Time;
        Throughput = (float)pcbs.size() / Finishing_Time * 100;
        Avg_tt = Sum_tt / pcbs.size();
        Avg_wt = Sum_wt / pcbs.size();

        System.out.println("-- Summary Data --");

        System.out.println("Finishing time : " + Finishing_Time);
        System.out.println("CPU utilization : " + CPU_utilization);
        System.out.println("I/O utilization : " + IO_utilization);
        System.out.println("Throughput : " + Throughput);
        System.out.println("Average turnaround time : " + Avg_tt);
        System.out.println("Average waiting time : " + Avg_wt);

        System.out.println();
    }

    public static void timed() {
        for(pcb p : pcbs) {
            p.timed();
        }
    }
}

// Strategy Pattern을 이용하여 스케줄링 방식을 구현
interface Strategy {
    public void scheduling();
}

class FCFS implements Strategy {
    private static FCFS instance = new FCFS();
    private FCFS() {}
    public static FCFS getInstance() {
        return instance;
    }

    public void scheduling() {
        WaitingQueue.run();
        ReadyQueue.run();
        CPUScheduler.timed();
        CPU.run();
    }
}

class RR1 implements Strategy {
    private static RR1 instance = new RR1();
    private RR1() {}
    public static RR1 getInstance() {
        return instance;
    }

    public void scheduling() {
        WaitingQueue.run();
        ReadyQueue.run();
        CPUScheduler.timed();
        CPU.run();
        if(CPUScheduler.gettime() % 1 == 0)
            CPU.preemption();
    }
}

class RR10 implements Strategy {
    private static RR10 instance = new RR10();
    private RR10() {}
    public static RR10 getInstance() {
        return instance;
    }

    public void scheduling() {
        WaitingQueue.run();
        ReadyQueue.run();
        CPUScheduler.timed();
        CPU.run();
        if(CPUScheduler.gettime() % 10 == 0)
            CPU.preemption();
    }
}

class RR100 implements Strategy {
    private static RR100 instance = new RR100();
    private RR100() {}
    public static RR100 getInstance() {
        return instance;
    }

    public void scheduling() {
        WaitingQueue.run();
        ReadyQueue.run();
        CPUScheduler.timed();
        CPU.run();
        if(CPUScheduler.gettime() % 100 == 0)
            CPU.preemption();
    }
}

class SJF implements Strategy {
    private static SJF instance = new SJF();
    private SJF() {}
    public static SJF getInstance() {
        return instance;
    }

    public void scheduling() {
        WaitingQueue.run();
        ReadyQueue.sortProcess();
        ReadyQueue.run();
        CPUScheduler.timed();
        CPU.run();
    }
}